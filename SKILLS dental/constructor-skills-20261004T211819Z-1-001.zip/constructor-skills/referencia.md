# Referencia del constructor de skills

Referencia técnica completa de las skills de Claude Code. Este documento cubre todos los campos del frontmatter, los patrones avanzados, el paso de argumentos, la resolución de problemas y cómo encajan las skills en tu proyecto.

Fuente oficial (en inglés): https://code.claude.com/docs/en/skills

---

## Entender la diferencia entre CLAUDE.md y las skills

Este es el concepto más importante de todos, antes de ponerte a construir skills. Dónde pongas las instrucciones determina cómo las usa Claude.

| | CLAUDE.md | Skill |
|---|---|---|
| **Cuándo se carga** | En cada conversación, siempre | Solo cuando se invoca (con `/nombre` o por detección automática) |
| **Para qué sirve** | Reglas, convenciones y contexto de todo el proyecto | Procesos de tareas concretas, procedimientos especializados |
| **Cuidado con el tamaño** | Está siempre en contexto, así que mantenlo centrado | Solo se carga cuando hace falta, pero no pases de 500 líneas |
| **Ejemplos** | "Usa TypeScript en todos los archivos", "Ejecuta las pruebas antes de hacer commit", convenciones de la API | "Genera un resumen de la PR", "Crea notas de reunión", "Despliega a pruebas" |

**Regla práctica:** si Claude debe saberlo *siempre*, va en el CLAUDE.md. Si solo debe saberlo al hacer una tarea concreta, hazlo una skill.

Las instrucciones del CLAUDE.md siguen aplicándose mientras se ejecuta una skill. Una skill hereda las reglas de tu proyecto, no las sustituye. Piénsalo por capas: el CLAUDE.md es la capa de base y la skill añade encima las instrucciones de la tarea.

---

## Referencia de campos del frontmatter

Todos los campos son opcionales. Solo se recomienda `description`.

| Campo | Obligatorio | Tipo | Por defecto | Descripción |
|-------|-------------|------|-------------|-------------|
| `name` | No | texto | nombre de la carpeta | Nombre visible y `/comando`. Solo minúsculas, números y guiones. Máximo 64 caracteres. |
| `description` | Recomendado | texto | primer párrafo del contenido | Qué hace la skill y cuándo usarla. Claude lo usa para decidir si la invoca sola. |
| `argument-hint` | No | texto | ninguno | Pista de autocompletado de los argumentos esperados. Se ve en el menú `/`. Ejemplos: `[numero-incidencia]`, `[archivo] [formato]` |
| `disable-model-invocation` | No | booleano | `false` | Con `true`, solo la persona puede invocar la skill. La saca del contexto de Claude por completo. |
| `user-invocable` | No | booleano | `true` | Con `false`, oculta la skill del menú `/`. Solo Claude puede invocarla. |
| `allowed-tools` | No | texto (separado por comas) | todas | Herramientas disponibles sin pedir permiso mientras la skill está activa. |
| `model` | No | texto | hereda | Modelo a usar: `sonnet`, `opus`, `haiku`, o déjalo vacío para heredar. |
| `context` | No | texto | ninguno | Ponlo en `fork` para ejecutarla en el contexto aislado de un subagente. |
| `agent` | No | texto | `general-purpose` | Tipo de subagente cuando `context: fork` está puesto. Opciones: `Explore`, `Plan`, `general-purpose`, o cualquier agente propio. |
| `hooks` | No | objeto | ninguno | Hooks de ciclo de vida limitados a esta skill. Mira la sección de hooks más abajo. |

---

## Tabla de control de invocación

Cómo se combinan `disable-model-invocation` y `user-invocable`:

| Frontmatter | ¿Puede invocarla la persona? | ¿Puede invocarla Claude? | Cuándo se carga en contexto |
|-------------|------------------------------|--------------------------|------------------------------|
| (por defecto, sin poner ninguno) | Sí | Sí | La descripción está siempre en contexto. La skill completa se carga al invocarla. |
| `disable-model-invocation: true` | Sí | No | La descripción NO está en contexto. La skill completa se carga cuando la invoca la persona. |
| `user-invocable: false` | No | Sí | La descripción está siempre en contexto. La skill completa se carga cuando la invoca Claude. |

Matices importantes:
- `user-invocable` solo controla si se ve en el menú `/`, NO afecta a la herramienta Skill. Para bloquear la invocación desde código, usa `disable-model-invocation: true`.
- `disable-model-invocation: true` es la restricción más fuerte. Saca la skill del contexto de Claude por completo Y le impide acceder a ella con la herramienta Skill.

---

## Sustituciones de texto

Marcadores disponibles dentro del contenido de una skill:

| Variable | Descripción | Ejemplo |
|----------|-------------|---------|
| `$ARGUMENTS` | Todos los argumentos que se pasan al invocar la skill | `/arreglar-incidencia 123` da `$ARGUMENTS` = `123` |
| `$ARGUMENTS[N]` | Un argumento concreto, contando desde 0 | `$ARGUMENTS[0]` = primer argumento |
| `$N` | Forma corta de `$ARGUMENTS[N]` | `$0` = primer argumento, `$1` = segundo |
| `${CLAUDE_SESSION_ID}` | Identificador de la sesión actual | Útil para registros y archivos propios de la sesión |

**Reserva automática:** si `$ARGUMENTS` NO aparece en ninguna parte del contenido de la skill, los argumentos se añaden automáticamente al final como `ARGUMENTS: <valor>`.

**Ejemplo con argumentos por posición:**

```yaml
---
name: migrar-componente
description: Migra un componente de un framework a otro
argument-hint: [componente] [framework-origen] [framework-destino]
---

Migra el componente $0 de $1 a $2.
Conserva todo el comportamiento y las pruebas que ya existen.
```

Al ejecutar `/migrar-componente BarraBusqueda React Vue`, `$0` se sustituye por `BarraBusqueda`, `$1` por `React` y `$2` por `Vue`.

---

## Dónde se guardan las skills

El sitio donde guardes una skill determina quién puede usarla:

| Ubicación | Ruta | A quién afecta | Prioridad |
|-----------|------|----------------|-----------|
| Empresa | Ajustes gestionados | A toda la organización | La más alta |
| Personal | `~/.claude/skills/<nombre>/SKILL.md` | A todos tus proyectos | Alta |
| Proyecto | `.claude/skills/<nombre>/SKILL.md` | Solo a este proyecto | Media |
| Plugin | `<plugin>/skills/<nombre>/SKILL.md` | Donde el plugin esté activado | La más baja |

Cuando dos skills comparten nombre en niveles distintos, gana la de mayor prioridad. Las skills de plugin usan el espacio de nombres `nombre-plugin:nombre-skill`, así que no pueden chocar.

**Monorepos:** al editar archivos en subcarpetas, Claude Code descubre solo las skills de las carpetas `.claude/skills/` anidadas (por ejemplo, `paquetes/frontend/.claude/skills/`).

**Carpetas añadidas:** las skills que estén en `.claude/skills/` dentro de carpetas pasadas con `--add-dir` se cargan automáticamente y detectan cambios en vivo.

---

## Guía de sintaxis de `allowed-tools`

El campo `allowed-tools` restringe qué herramientas puede usar Claude sin pedir permiso mientras la skill está activa. Tus ajustes globales de permisos siguen aplicándose por encima de esto.

**Sintaxis básica, nombres separados por comas:**

```yaml
allowed-tools: Read, Grep, Glob
```

Claude puede usar estas libremente. Cualquier otra herramienta pedirá permiso.

**Patrones por herramienta con comodines:**

```yaml
allowed-tools: Bash(git *), Bash(npm test), Read
```

El patrón que va entre paréntesis filtra qué argumentos puede pasar Claude:

| Patrón | Qué permite |
|--------|-------------|
| `Bash` | Cualquier comando (sin restricción) |
| `Bash(git *)` | Cualquier comando que empiece por `git` (por ejemplo `git status`, `git diff`) |
| `Bash(npm test)` | Solo el comando exacto `npm test` |
| `Bash(python scripts/*)` | Python sobre cualquier archivo de `scripts/` |
| `Read` | Leer cualquier archivo (sin restricción de argumentos) |

**Patrones habituales:**

```yaml
# Skill de solo lectura (no modifica archivos)
allowed-tools: Read, Grep, Glob

# Solo puede ejecutar comandos concretos
allowed-tools: Bash(git status), Bash(git diff), Read

# Solo puede usar herramientas de internet
allowed-tools: WebSearch, WebFetch

# Puede leer archivos y ejecutar un script concreto
allowed-tools: Read, Glob, Bash(python scripts/analizar.py *)
```

**Importante:** `allowed-tools` añade aprobaciones automáticas *por encima* de tus ajustes de permisos actuales. No quita permisos que ya hayas concedido de forma global.

---

## Patrones avanzados

### Inyección de contexto dinámico

La sintaxis `` !`comando` `` ejecuta comandos de terminal ANTES de que el contenido de la skill llegue a Claude. La salida del comando sustituye al marcador en el mismo sitio.

```yaml
---
name: resumen-pr
description: Resume los cambios de una pull request
context: fork
agent: Explore
allowed-tools: Bash(gh *)
---

## Contexto de la pull request
- Cambios: !`gh pr diff`
- Comentarios: !`gh pr view --comments`
- Archivos tocados: !`gh pr diff --name-only`

## Tu tarea
Resume esta pull request...
```

Al ejecutarse:
1. Cada `` !`comando` `` se ejecuta de inmediato (antes de que Claude vea nada)
2. La salida sustituye al marcador
3. Claude recibe el prompt ya montado, con los datos reales dentro

Esto es preprocesado. Claude solo ve el resultado final, no los comandos.

**Para qué sirve:**
- Meter el estado de git, la rama o los cambios
- Traer respuestas de una API en vivo
- Leer variables de entorno o archivos de configuración
- Sacar listados de archivos o datos del proyecto

### Ejecutar una skill en un subagente (context: fork)

Añade `context: fork` para ejecutar una skill en el contexto aislado de un subagente. El contenido de la skill se convierte en el encargo del subagente. El subagente NO tiene acceso al historial de tu conversación.

```yaml
---
name: investigacion-profunda
description: Investiga un tema a fondo
context: fork
agent: Explore
---

Investiga $ARGUMENTS a fondo:

1. Encuentra los archivos relevantes con Glob y Grep
2. Lee y analiza el código
3. Resume lo que has encontrado, citando archivos concretos
```

**Cuándo usar `context: fork`:**
- La tarea es autónoma y no necesita el historial de la conversación
- La skill produce mucha salida y no quieres ensuciar el contexto principal
- Quieres imponer restricciones de herramientas mediante el tipo de agente
- La skill es cara de ejecutar y basta con un modelo más barato

**Cuándo NO usarlo:**
- La skill contiene pautas (del tipo "usa estas convenciones de la API") sin una tarea concreta. El subagente recibe las pautas pero no tiene nada que hacer y no devuelve nada útil.
- La skill necesita conversación de ida y vuelta con la persona
- La skill necesita contexto de la conversación en curso

**Opciones de agente:**
- `Explore`: Haiku, solo lectura. El mejor para investigar, encontrar archivos y buscar en el código.
- `Plan`: hereda el modelo, solo lectura. El mejor para investigación de cara a planificar.
- `general-purpose`: hereda el modelo, todas las herramientas. El mejor para tareas complejas de varios pasos.
- Cualquier agente propio que tengas en `.claude/agents/`.

**Las skills y los subagentes se combinan en dos direcciones:**

| Enfoque | Prompt de sistema | Encargo | Además carga |
|---------|-------------------|---------|--------------|
| Skill con `context: fork` | El del tipo de agente | El contenido del SKILL.md | El CLAUDE.md |
| Subagente con campo `skills` | El cuerpo del markdown del subagente | El mensaje de delegación de Claude | Las skills precargadas y el CLAUDE.md |

### Archivos de apoyo

Una skill puede incluir varios archivos en su carpeta. Mantén el SKILL.md por debajo de 500 líneas y mueve el material de referencia detallado a archivos aparte.

```
mi-skill/
  SKILL.md              # Instrucciones principales (obligatorio, menos de 500 líneas)
  referencia.md         # Documentación detallada
  scripts/
    ayudante.py         # Script de apoyo
```

Menciónalos desde el SKILL.md para que Claude sepa que existen. Los archivos de apoyo NO se cargan solos, se cargan únicamente cuando Claude los necesita.

### Hooks dentro de una skill

Una skill puede definir hooks de ciclo de vida en su frontmatter. Estos hooks solo se ejecutan mientras la skill está activa.

```yaml
---
name: editor-seguro
description: Edita archivos pasando el linter automáticamente
hooks:
  PreToolUse:
    - matcher: "Bash"
      hooks:
        - type: command
          command: "./scripts/validar-comando.sh"
  PostToolUse:
    - matcher: "Edit|Write"
      hooks:
        - type: command
          command: "./scripts/pasar-linter.sh"
---
```

**Eventos de hook admitidos en skills:**

| Evento | Entrada del matcher | Cuándo se dispara |
|--------|---------------------|-------------------|
| `PreToolUse` | Nombre de la herramienta | Antes de que la skill use una herramienta |
| `PostToolUse` | Nombre de la herramienta | Después de que la skill use una herramienta |
| `Stop` | (ninguna) | Cuando la skill termina (en ejecución se convierte en SubagentStop) |

Los comandos de hook reciben datos en JSON por entrada estándar, con el contexto de la herramienta. Código de salida 0 = permitir, código de salida 2 = bloquear.

### Salida visual (scripts incluidos)

Una skill puede traer scripts que generen salida visual (HTML, imágenes, gráficos). Esto amplía lo que Claude puede hacer más allá del texto.

````yaml
---
name: visualizador-codigo
description: Genera un árbol interactivo de tu código
allowed-tools: Bash(python *)
---

# Visualizador de código

Ejecuta el script de visualización:

```bash
python ~/.claude/skills/visualizador-codigo/scripts/visualizar.py .
```
````

La skill aporta las instrucciones de coordinación y el script incluido hace el trabajo pesado. Este patrón sirve para grafos de dependencias, informes de cobertura de pruebas, documentación de API o cualquier salida visual.

### Pensamiento extendido (ultrathink)

Claude Code tiene un modo de pensamiento extendido que le permite razonar más a fondo antes de responder. Para activarlo dentro de una skill, incluye la palabra `ultrathink` en cualquier parte del contenido.

**Cuándo usarlo:**
- Análisis complejos en los que hay que sopesar varios factores
- Decisiones de arquitectura con ventajas e inconvenientes
- Depuración en la que importa encontrar la causa raíz
- Cualquier tarea en la que quieras que Claude "piense más" antes de actuar

**Ejemplo:**
```yaml
---
name: revision-arquitectura
description: Revisa y critica decisiones de arquitectura
---

ultrathink

Revisa la arquitectura de este código...
```

La palabra puede ir en cualquier sitio: en un comentario, en un encabezado o en mitad del texto. Con que esté, ya activa el pensamiento extendido durante la ejecución de esa skill.

---

## Permisos y control de acceso

### Restringir a qué skills accede Claude

Tres formas de controlar qué skills puede invocar Claude:

**1. Desactivar todas las skills** denegando la herramienta Skill en `/permissions`:
```
# Añadir a las reglas de denegación:
Skill
```

**2. Permitir o denegar skills concretas** con reglas de permisos:
```
# Permitir solo skills concretas
Skill(commit)
Skill(review-pr *)

# Denegar skills concretas
Skill(deploy *)
```

Sintaxis: `Skill(nombre)` para coincidencia exacta, `Skill(nombre *)` para coincidencia por prefijo con cualquier argumento.

**3. Ocultar skills sueltas** añadiendo `disable-model-invocation: true` a su frontmatter.

---

## Resolución de problemas

### La skill no se dispara

Si Claude no usa tu skill cuando debería:

1. **Revisa la descripción.** ¿Incluye las palabras que diría la gente de forma natural? La descripción es lo que Claude usa para decidir si carga la skill.
2. **Comprueba que se ve.** Pregunta "¿qué skills hay disponibles?" para confirmar que Claude la ve.
3. **Dilo de otra manera.** Prueba una redacción más parecida a la descripción.
4. **Invócala directamente.** Usa `/nombre-skill` para confirmar que la skill funciona.
5. **Mira `disable-model-invocation`.** Si está en `true`, Claude no puede invocarla solo. Solo funciona `/nombre-skill`.

### La skill se dispara demasiado

Si Claude usa tu skill cuando no quieres:

1. **Haz la descripción más específica.** Estrecha las condiciones que la disparan.
2. **Añade `disable-model-invocation: true`.** Si solo quieres invocarla a mano.

### Claude no ve todas las skills

Las descripciones de las skills se cargan en contexto. Si tienes muchas, pueden superar el presupuesto de caracteres (2% de la ventana de contexto, con un tope de reserva de 16.000 caracteres entre TODAS las skills).

- Comprobación: ejecuta `/context` para ver si se está dejando fuera alguna skill.
- Arreglo: mantén las descripciones breves y con palabras clave. Si hace falta, súbelo con la variable de entorno `SLASH_COMMAND_TOOL_CHAR_BUDGET`.

### Una skill en subagente no devuelve nada útil

Si una skill con `context: fork` devuelve resultados vacíos o inservibles:

- Lo más probable es que la skill contenga pautas pero ninguna tarea concreta. Un subagente necesita algo que hacer, no solo material de referencia.
- Añade instrucciones explícitas: "Haz X y después devuelve Y".

### Los argumentos no se sustituyen

- Comprueba que `$ARGUMENTS`, `$N` o `$ARGUMENTS[N]` aparecen en el contenido de la skill.
- Si no aparece ninguno, los argumentos se añaden al final como `ARGUMENTS: <valor>` (la reserva automática).
- Los argumentos se separan por espacios. Si un argumento lleva espacios dentro, puede partirse donde no esperas.

---

## Documentación relacionada

Toda la documentación oficial está en inglés:

- **Skills:** https://code.claude.com/docs/en/skills
- **Subagentes:** https://code.claude.com/docs/en/sub-agents
- **Hooks:** https://code.claude.com/docs/en/hooks
- **Plugins:** https://code.claude.com/docs/en/plugins
- **Memoria (CLAUDE.md):** https://code.claude.com/docs/en/memory
- **Permisos:** https://code.claude.com/docs/en/permissions
- **Modo interactivo:** https://code.claude.com/docs/en/interactive-mode
