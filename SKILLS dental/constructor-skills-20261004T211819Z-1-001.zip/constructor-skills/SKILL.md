---
name: constructor-skills
description: Úsala cuando alguien quiera crear una skill nueva, mejorar una que ya existe, auditar la calidad de una skill o arreglar una que no se dispara. Guía la construcción de skills siguiendo las buenas prácticas oficiales de Claude Code.
---

## Qué hace esta skill

Guía la creación y la mejora de skills de Claude Code siguiendo las buenas prácticas oficiales. Úsala siempre que:

- Estés creando una skill desde cero
- Quieras mejorar o auditar una skill que ya existe
- Tengas que decidir si usar funciones avanzadas (ejecución en subagente, hooks, contexto dinámico, etc.)
- Una skill no esté funcionando como debería

Para la referencia técnica completa de todos los campos del frontmatter, los patrones avanzados y la resolución de problemas, mira [referencia.md](referencia.md).

## Para empezar: qué es una skill

Una skill es un conjunto de instrucciones reutilizables que le dice a Claude Code cómo resolver una tarea concreta. Las skills viven en `.claude/skills/[nombre-skill]/SKILL.md` dentro de tu proyecto. Cuando escribes `/nombre-skill` o describes lo que necesitas en lenguaje normal, Claude carga las instrucciones de la skill y las sigue.

Piensa en las skills como los procedimientos de trabajo de Claude. En vez de volver a explicar un proceso en cada conversación, lo escribes una vez y lo invocas siempre.

**Cómo funciona por dentro:**
- Las instrucciones del `CLAUDE.md` de tu proyecto se cargan siempre, en cada conversación
- Las *descripciones* de las skills (las del frontmatter) se cargan siempre, para que Claude sepa de qué dispone
- El contenido completo de la skill solo se carga cuando la skill se invoca de verdad
- Una vez cargada, Claude sigue las instrucciones de la skill sin dejar de respetar las reglas de tu CLAUDE.md

---

## Modo 1: crear una skill nueva

Cuando vayas a crear una skill, haz primero la **entrevista inicial**. NO empieces a escribir archivos hasta que la entrevista esté terminada.

### Entrevista inicial

Haz las preguntas con AskUserQuestion, una ronda cada vez. Cada ronda cubre un tema. Pasa a la siguiente ronda solo cuando la persona haya respondido. Sigue hasta tener un 95% de certeza de que entiendes la skill lo bastante bien como para construirla sin más aclaraciones.

**Ronda 1: objetivo y nombre**
*Por qué importa: un objetivo claro evita que la skill se desmadre. El nombre se convierte en el `/comando`, así que tiene que ser fácil de recordar y específico.*

- ¿Qué hace esta skill? ¿Qué problema resuelve o qué proceso automatiza?
- ¿Cómo la llamamos? (Propón un nombre a partir de su respuesta: minúsculas, guiones, máximo 64 caracteres)

**Ronda 2: qué la dispara**
*Por qué importa: el campo `description` es lo que Claude usa para decidir si carga tu skill. Si las palabras que la disparan están mal elegidas, Claude no la usará nunca. Si son demasiado amplias, la lanzará cuando no toca.*

- ¿Qué diría alguien para que se dispare? (Consigue dos o tres frases en lenguaje normal)
- ¿Debe poder lanzarla solo la persona (`/comando`), solo Claude de forma automática, o las dos cosas?
- ¿Acepta argumentos? Si es así, ¿cuáles? (por ejemplo, un tema, una dirección web, una ruta de archivo)

**Ronda 3: el proceso, paso a paso**
*Por qué importa: Claude sigue las instrucciones al pie de la letra. Pasos vagos dan resultados vagos. Pasos concretos dan el mismo resultado siempre.*

- Cuéntame exactamente qué tiene que pasar, desde que se dispara hasta que sale el resultado. ¿Cuál es el paso 1? ¿Y el 2? Sigue.
- Para cada paso: ¿lo hace Claude directamente o lo delega a un subagente o a un script?
- ¿Necesita conversación de ida y vuelta con la persona, o es una tarea de lanzar y olvidar?

**Ronda 4: entradas, salidas y dependencias**
*Por qué importa: una skill que no dice de dónde salen los datos ni dónde van los resultados produce cosas distintas cada vez. Cerrar esto es lo que la hace fiable.*

- ¿Qué necesita de entrada? (Archivos, respuestas de una API, argumentos, datos en vivo)
- ¿Qué produce? (Archivos, texto, datos estructurados) ¿Dónde se guarda?
- ¿Necesita API externas, scripts o herramientas? ¿Cuáles?
- ¿Necesita archivos de referencia, guías de estilo, plantillas o ejemplos?

**Ronda 5: límites y casos raros**
*Por qué importa: una skill sin límites puede hacer cosas que no esperabas: resultados equivocados, gastos innecesarios en API o acciones que no pretendías.*

- ¿Qué puede salir mal? ¿Cuáles son los fallos más típicos?
- ¿Qué NO debe hacer esta skill nunca? ¿Hay alguna línea roja?
- ¿Hay algo que cueste dinero? (Llamadas a API, generación de imágenes con IA, etc.)
- ¿Hay restricciones de orden o dependencias? (Por ejemplo, "antes de hacer Y hay que comprobar X")

**Ronda 6: confirmación**
*Por qué importa: un malentendido que se pilla aquí te ahorra rehacer la skill entera después.*

Cuando termines todas las rondas, resume lo que has entendido con este formato:

```
## Resumen de la skill: [nombre]

**Objetivo:** [una frase]
**Se dispara con:** `/nombre` + [frases en lenguaje normal]
**Argumentos:** [qué acepta, o "ninguno"]

**Proceso:**
1. [paso]
2. [paso]
...

**Entradas:** [qué lee o necesita]
**Salidas:** [qué produce y dónde]
**Dependencias:** [API, scripts, agentes, archivos de referencia]
**Límites:** [qué puede salir mal, qué hay que evitar]
```

Después pregunta: "¿Es esto? ¿Añadirías o cambiarías algo?". No pases a construir hasta que te lo confirme.

**Saltarse rondas:** si la persona ya te ha dado suficiente contexto de entrada (por ejemplo, te describe el proceso entero en su primer mensaje), sáltate las rondas que ya están respondidas. No vuelvas a preguntar lo que ya sabes.

### Fase de construcción

Cuando la entrevista esté terminada, construye la skill siguiendo estos pasos:

**Paso 1: elige el tipo de skill**

- **Skills de tarea** (las más habituales): dan instrucciones paso a paso para una acción concreta. Se invocan con `/nombre` o en lenguaje normal. Ejemplos: generar un informe, resumir una PR, desplegar código.
- **Skills de referencia**: aportan conocimiento que Claude aplica al trabajo que ya está haciendo, sin ejecutar ninguna acción. Ejemplos: convenciones de código, patrones de una API, guías de estilo.

**Paso 2: configura el frontmatter**

Rellena estos campos según lo que hayas aprendido en la entrevista:

- `name`: coincide con el nombre de la carpeta. Minúsculas, guiones, máximo 64 caracteres.
- `description`: se escribe así: "Úsala cuando alguien pida [acción], [acción] o [acción]". Incluye las palabras naturales de las frases que la disparan.
- `disable-model-invocation: true`: ponlo si la skill tiene efectos secundarios (genera archivos, llama a API, cuesta dinero). Evita que Claude la invoque por su cuenta.
- `argument-hint`: ponlo si la skill acepta argumentos. Se ve en el autocompletado del menú `/`.
- `context: fork` + `agent`: ponlo si la skill es autónoma y no necesita el historial de la conversación.
- `model`: ponlo solo si hace falta la capacidad de un modelo concreto.
- `allowed-tools`: ponlo si la skill debe tener acceso restringido a herramientas.

Rellena solo los campos que necesites de verdad. No añadas frontmatter porque sí.

Para la referencia completa de campos y la tabla de control de invocación, mira [referencia.md](referencia.md).

**Paso 3: escribe el contenido de la skill**

Estructura las skills de tarea así:
1. **Contexto**: archivos que hay que leer, API que hay que llamar, material de referencia que hay que cargar
2. **Proceso paso a paso**: pasos numerados. Cada paso le dice a Claude exactamente qué hacer.
3. **Formato de salida**: qué aspecto tiene el resultado. Incluye plantillas, rutas de archivo, formatos concretos.
4. **Notas**: casos raros, restricciones, qué delegar y qué NO hacer.

Reglas del contenido:
- Mantén el SKILL.md por debajo de 500 líneas. El material de referencia detallado va a archivos aparte.
- Usa `$ARGUMENTS` o `$N` para la entrada dinámica que llega por argumentos.
- Usa `` !`comando` `` para inyectar contexto dinámico (se ejecuta antes que nada).
- Sé concreto al delegar en un agente: incluye el texto exacto del prompt.
- Especifica todas las rutas de archivo (entradas, salidas, scripts, referencias).

**Paso 4: añade archivos de apoyo (si hacen falta)**

Si tu skill necesita documentación detallada, ejemplos o scripts, ponlos junto al SKILL.md en la misma carpeta. Menciónalos desde el SKILL.md para que Claude sepa que existen. Los archivos de apoyo NO se cargan solos, se cargan únicamente cuando Claude los necesita. El patrón completo está en [referencia.md](referencia.md).

**Paso 5: documéntala en el CLAUDE.md**

El `CLAUDE.md` de tu proyecto es donde Claude carga las instrucciones generales en cada conversación. Después de crear una skill, añade una entrada breve para que tú (y tu equipo) sepáis de qué disponéis:

- Nombre de la skill y su `/comando`
- Frases que la disparan
- Descripción breve de lo que hace
- Dónde deja los resultados (si genera archivos)

Esto no hace falta para que la skill funcione, pero mantiene el proyecto ordenado y ayuda a Claude a entender cómo encajan las skills en tu forma de trabajar.

**Paso 6: pruébala**

Prueba las dos formas de invocarla:

1. **Lenguaje normal**: di algo que encaje con la descripción. ¿Carga Claude la skill?
   - Si no, revisa el campo `description` para que incluya las palabras que has usado
   - Prueba dos o tres formas distintas de decirlo, para confirmar que se dispara de forma fiable
2. **Invocación directa**: ejecuta `/nombre-skill` con argumentos de prueba
   - Comprueba que `$ARGUMENTS` y `$N` se sustituyen bien
   - Comprueba que los resultados van donde deben
3. **Casos raros**: prueba a invocarla sin argumentos, con una entrada rara o vacía
4. **Presupuesto de caracteres**: si tienes muchas skills, ejecuta `/context` para confirmar que la descripción de tu skill se está cargando. Si no aparece, puede que el total de descripciones supere el presupuesto (los detalles están en [referencia.md](referencia.md)).

Si algo falla, mira la sección de resolución de problemas de [referencia.md](referencia.md).

### Ejemplo completo

Aquí tienes una skill mínima pero completa que puedes usar como plantilla de partida:

**Archivo:** `.claude/skills/notas-reunion/SKILL.md`

````yaml
---
name: notas-reunion
description: Úsala cuando alguien pida resumir las notas de una reunión, hacer un resumen de lo hablado o dar formato a un acta.
argument-hint: [tema o fecha]
---

## Qué hace esta skill

Coge notas de reunión en bruto y produce un resumen estructurado con tareas pendientes.

## Pasos

1. Pide que peguen las notas en bruto (o que den una ruta de archivo).
2. Saca de las notas lo siguiente:
   - **Asistentes**: quién estaba en la reunión
   - **Decisiones**: qué se decidió
   - **Tareas**: quién tiene que hacer qué, con fecha si se mencionó
   - **Preguntas abiertas**: lo que quedó sin resolver
3. Da formato al resultado con la plantilla de abajo.
4. Si hay $ARGUMENTS, úsalo como título de la reunión. Si no, dedúcelo del contenido.

## Plantilla de salida

# Reunión: [título]
**Fecha:** [fecha si se menciona, si no "sin especificar"]
**Asistentes:** [lista separada por comas]

## Decisiones
- [decisión]

## Tareas
- [ ] [persona]: [tarea] (fecha: [fecha o "por definir"])

## Preguntas abiertas
- [pregunta]

## Notas

- Resúmenes breves. No añadas comentarios ni adornes.
- Si las notas son demasiado vagas para sacar tareas, dilo en vez de inventártelas.
````

---

## Modo 2: auditar una skill que ya existe

Usa esta lista para auditar cualquier skill. Lee el archivo de la skill antes de empezar la lista. Arregla lo que falle antes de dar la auditoría por terminada.

### Auditoría del frontmatter

- [ ] `name` coincide con el nombre de la carpeta
- [ ] `description` usa palabras naturales, las que alguien diría de verdad cuando necesita esta skill
- [ ] `description` es lo bastante específica para no dispararse sin motivo, y lo bastante amplia para pillar las peticiones reales
- [ ] `disable-model-invocation: true` está puesto si la skill tiene efectos secundarios (genera archivos, llama a API, envía mensajes, cuesta dinero)
- [ ] `argument-hint` está puesto si la skill acepta argumentos por `/nombre`
- [ ] `allowed-tools` está puesto si la skill NO debe tener acceso a todas las herramientas
- [ ] `context: fork` se usa si la skill es autónoma y produce mucha salida
- [ ] `model` solo está puesto si hace falta la capacidad de un modelo concreto
- [ ] No hay campos innecesarios (no añadas frontmatter porque sí)

### Auditoría del contenido

- [ ] El SKILL.md entero está por debajo de 500 líneas (la referencia detallada se ha movido a archivos de apoyo)
- [ ] Hay un proceso claro, paso a paso y numerado (en las skills de tarea)
- [ ] El formato de salida está especificado con plantillas o ejemplos
- [ ] Todas las rutas y ubicaciones están documentadas
- [ ] Las instrucciones de delegación a un agente incluyen el texto real del prompt que hay que enviar
- [ ] La sección de notas cubre casos raros, restricciones y qué NO hacer
- [ ] No hay instrucciones vagas: cada paso le dice a Claude exactamente qué hacer
- [ ] Se usan las sustituciones (`$ARGUMENTS`, `$N`) donde la skill recibe entrada

### Auditoría de integración

- [ ] La skill está documentada en el CLAUDE.md (recomendable, no obligatorio)
- [ ] Los archivos de apoyo (si los hay) se mencionan desde el SKILL.md, no están sueltos
- [ ] Los scripts (si los hay) tienen las rutas correctas y se pueden ejecutar
- [ ] Las claves de API (si las hay) están en variables de entorno, nunca escritas a pelo en el archivo

### Auditoría de calidad

- [ ] Alguien que empieza podría seguir las instrucciones sin contexto previo
- [ ] Las instrucciones son accionables, no abstractas
- [ ] Delega en subagentes cuando conviene, para no ensuciar el contexto principal
- [ ] No repite información que ya vive en otro sitio (CLAUDE.md, otras skills)
- [ ] Las rutas de salida siguen una convención previsible

### Oportunidades de mejora

Cuando termines la auditoría, mira [referencia.md](referencia.md) por si alguna función avanzada mejoraría la skill: `context: fork`, `allowed-tools`, inyección de contexto dinámico, hooks y archivos de apoyo.

---

## Convenciones recomendadas

Adáptalas a tu proyecto:

- Las skills viven en `.claude/skills/[nombre-skill]/SKILL.md`
- Los archivos de salida van a un sitio previsible (por ejemplo, `output/[nombre-skill]/`)
- Las claves de API van en variables de entorno, nunca escritas a pelo en los archivos de la skill
- Documenta todas las skills activas en el CLAUDE.md de tu proyecto
- El campo `description` del frontmatter se escribe así: "Úsala cuando alguien pida [acción], [acción] o [acción]"

## Notas importantes

- Lee siempre una skill antes de mejorarla. Nunca propongas cambios sobre una skill que no has leído.
- Antes de crear una skill nueva, comprueba si ya existe una parecida que se pueda ampliar.
- Para los patrones avanzados (ejecución en subagente, hooks, permisos), mira [referencia.md](referencia.md).
